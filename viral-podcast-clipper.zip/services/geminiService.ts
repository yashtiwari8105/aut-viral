
import { GoogleGenAI, Type } from "@google/genai";
import { Clip } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const clipSchema = {
  type: Type.OBJECT,
  properties: {
    title: {
      type: Type.STRING,
      description: "A catchy, viral-style title for the short clip. Should be under 70 characters.",
    },
    hook: {
      type: Type.STRING,
      description: "The powerful hook for the first 3-5 seconds of the video to grab viewer attention.",
    },
    description: {
      type: Type.STRING,
      description: "A brief summary of the clip's content, explaining the key moment or dialogue.",
    },
    visualSuggestions: {
      type: Type.STRING,
      description: "Actionable visual editing suggestions, like 'zoom in on speaker', 'use dramatic background music', or 'add bold captions'.",
    },
  },
  required: ["title", "hook", "description", "visualSuggestions"],
};

export const generateClips = async (youtubeUrl: string): Promise<Clip[]> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Based on a podcast from the following YouTube link, generate between 5 and 10 viral clip ideas. 
      YouTube link: ${youtubeUrl}

      IMPORTANT: You cannot access external URLs. Instead, based on common podcast topics (like tech, interviews, comedy, self-improvement, true crime), hypothesize the likely content and themes of a podcast from this link. Then, generate compelling and plausible clip ideas that would fit such a podcast.
      
      For each idea, provide the specific details requested in the JSON schema.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: clipSchema,
        },
      },
    });

    const responseText = response.text.trim();
    if (!responseText) {
      console.error("Gemini API returned an empty response.");
      return [];
    }
    
    const parsedClips = JSON.parse(responseText);
    return parsedClips as Clip[];

  } catch (error) {
    console.error("Error generating clips from Gemini API:", error);
    // It's better to re-throw or handle it gracefully so the UI can show an error.
    throw new Error("Failed to communicate with the AI model.");
  }
};
