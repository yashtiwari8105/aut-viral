
export interface Clip {
  title: string;
  hook: string;
  description: string;
  visualSuggestions: string;
}
