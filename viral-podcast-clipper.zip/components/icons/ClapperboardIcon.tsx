
import React from 'react';

const ClapperboardIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M21 7.5l-2.25-1.313M21 7.5v2.25m0-2.25l-2.25 1.313M3 7.5l2.25-1.313M3 7.5l2.25 1.313M3 7.5v2.25m9 3l2.25-1.313M12 12.75l-2.25-1.313M12 12.75V15m0 6.75l-2.25-1.313M12 21.75V19.5m0 2.25l2.25-1.313M12 19.5l2.25-1.313M12 19.5l-2.25-1.313m0-2.25l2.25 1.313m0 0l2.25 1.313m0 0l2.25 1.313m-9-1.313l2.25-1.313m2.25 1.313l2.25 1.313M3 12l2.25 1.313m0 0l2.25 1.313m0 0l2.25 1.313M21 12l-2.25 1.313m0 0l-2.25 1.313m0 0l-2.25 1.313M3 12h18M3 12l2.25-1.313M21 12l-2.25-1.313" />
  </svg>
);

export default ClapperboardIcon;
