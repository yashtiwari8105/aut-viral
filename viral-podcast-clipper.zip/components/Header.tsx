
import React from 'react';
import SparklesIcon from './icons/SparklesIcon';

const Header: React.FC = () => {
  return (
    <header className="text-center">
      <div className="flex items-center justify-center gap-4">
        <SparklesIcon className="w-10 h-10 text-cyan-400" />
        <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-fuchsia-500">
          Viral Podcast Clipper
        </h1>
      </div>
      <p className="mt-4 max-w-2xl mx-auto text-lg text-gray-400">
        Paste a YouTube podcast link below. Our AI will analyze its potential and generate 5-10 viral short clip ideas for you.
      </p>
      <p className="mt-2 text-xs text-gray-500 max-w-2xl mx-auto">
        Note: The AI hypothesizes content as it cannot access external URLs directly.
      </p>
    </header>
  );
};

export default Header;
