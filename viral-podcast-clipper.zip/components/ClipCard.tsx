
import React from 'react';
import { Clip } from '../types';
import ClapperboardIcon from './icons/ClapperboardIcon';

interface ClipCardProps {
  clip: Clip;
  index: number;
}

const ClipCard: React.FC<ClipCardProps> = ({ clip, index }) => {
  return (
    <div className="bg-gradient-to-br from-gray-800 to-gray-800/60 p-6 rounded-2xl border border-gray-700 shadow-lg hover:border-cyan-500/50 transition-all duration-300 flex flex-col gap-4 h-full">
      <div className="flex items-center gap-3">
        <div className="p-2 bg-cyan-500/20 rounded-full">
          <ClapperboardIcon className="w-6 h-6 text-cyan-400" />
        </div>
        <h3 className="text-xl font-bold text-gray-100">{clip.title}</h3>
      </div>
      
      <div className="space-y-4 flex-grow">
        <div>
          <h4 className="font-semibold text-cyan-400 mb-1">The Hook (First 3s)</h4>
          <p className="text-gray-300 text-sm">"{clip.hook}"</p>
        </div>
        <div>
          <h4 className="font-semibold text-fuchsia-400 mb-1">Description</h4>
          <p className="text-gray-300 text-sm">{clip.description}</p>
        </div>
        <div>
          <h4 className="font-semibold text-green-400 mb-1">Editing Suggestions</h4>
          <p className="text-gray-300 text-sm">{clip.visualSuggestions}</p>
        </div>
      </div>

    </div>
  );
};

export default ClipCard;
